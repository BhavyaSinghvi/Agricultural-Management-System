package Resources;

public class Crop {
    private String cropType;
    public Crop(String cropType){
        this.cropType = cropType;
    }

    public String getCropType() {
        return cropType;
    }
}
